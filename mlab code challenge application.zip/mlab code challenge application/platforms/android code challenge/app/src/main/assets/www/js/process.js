//a call to disable default back button
//demonstration of using device ready plugin.
//all plugins should be called under this device ready function
//firebase in app live notifications and other plugins
//by tyson MOYAHABO MOTLHABENG..
//mlab code challenge project.
//cordova framework
document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
    document.addEventListener("backbutton", function (e) {
        e.preventDefault();
    }, false);
}
//function click to refresh
var errors = document.getElementById('error_netowrk');
function refresh() {
    location.reload();
}
//Ajax call to get job listing data
function loaddata_jobs(){
  $.ajax({
    type: 'GET',
    url: '../php/job_listing.php',
    data: {"done" : 1},
    catch: 'true',
    success : function(data){
      //hide loader
      if(data == ""){
        $('.loader ').hide();
        $('#error_netowrk').show();
      }else {
        $('.loader ').hide();
        $('#error_netowrk').hide();
        //display data from php script
          $("#news_feeds").html(data);
      }
    },
    error: function (e) {
    //throw an error if there is not network
    $('.loader ').hide();
     $('#error_netowrk').show();
    }
  });
}
//calling ajax function
loaddata_jobs();
getjobid();
//about job page
  //function for getting url id
  function getjobid(){
    function ParseURLParameter(Parameter) {
        var FullURL = window.location.search.substring(1);
        var ParametersArray = FullURL.split('&');
        for (var i = 0; i < ParametersArray.length; i++) {
            var CurrentParameter = ParametersArray[i].split('=');
            if (CurrentParameter[0] == Parameter) {
                return CurrentParameter[1];
            }
        }
    }
    //stored job id
    var id = ParseURLParameter('id');
    //Ajax call to get data and post data from php script
    $.ajax({
      type: 'POST',
      url: '../php/about_job.php',
      data: {"done" : 1,id:id},
      catch: 'true',
      success : function(data){
        //hide loader
        if(data == ""){
            $('.loader ').hide();
            $('#error_netowrk').show();
        }else {
          $('.loader ').hide();
          $('#error_netowrk').hide();
            //display data from php script
          $("#about_job").html(data);
        }
      },
        error: function (e) {
      //throw an error if there is not network
        $('.loader ').hide();
        $('#error_netowrk').show();
      }
    });
  }

//search json data job searching
