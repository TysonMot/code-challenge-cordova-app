<?php
//Tyson Moyahabo 
//Full stack developer

$url ="https://us-central1-mlab-challenge.cloudfunctions.net/jobs";
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_ENCODING, "");
$curlData = curl_exec($curl);

$data = json_decode($curlData, true);

//data selection
//echo 'job id : '.$data['id'].'<br/><br/>';
//echo 'job type : '.$data['type'].'<br/><br/>';
//echo 'job website : '.$data['url'].'<br/><br/>';
//echo 'date posted : '.$data['created_at'].'<br/><br/>';
//echo 'company name : '.$data['company'].'<br/><br/>';
//echo 'comapny url : '.$data['company_url'].'<br/><br/>';
//echo 'job location : '.$data['location'].'<br/><br/>';
//echo 'job description : '.$data['description'].'<br/><br/>';
//echo 'how to apply : '.$data['how_to_apply'].'<br/><br/>';
//echo 'logo : '.$data['company_logo'].'<br/><br/>';

$i = 1;

foreach($data as $key=> $value){
      ///limit words 
    $short_description = strip_tags($value["description"]);
    if (strlen($short_description) > 150) {

    $Description_cut = substr($short_description, 0, 150);
    $Description_end = strrpos($Description_cut, ' ');

    $short_description = $Description_end? substr($Description_cut, 0, $Description_end) : substr($Description_cut, 0);
    $short_description .= '...';
    }
    
    //image url link company logo
    if($value["company_logo"] == ""){
        $img_link = "../img/default.png";
    }else {
        $img_link = $value["company_logo"];
    }
    
    ///display job listings
    
    $output .= '
    <div class="feeds-container">
    <!-- logo and company name, date here-->
    <div class="logo">
    <img src="'.$img_link.'" alt="">
    </div>

    <!-- news feeds name, dates-->
    <div class="company-info">
    <h2>'.$value["company"].'</h2>
    <p>'.$value["created_at"].'</p>
    <hr/>
    </div>

    <!-- news feeds details-->
    <div class="job-description">
    <h1>'.$value["title"].'</h1>
    <h5>'.$value["location"].'</h5>
    <p>'. $short_description .'</p>
    </div>
    <!-- news feeds learn more link-->
    <div class="job-learn-more">
    <a href="about.html?id='.$value["id"].'">view job</a>
    </div>
    </div>
    
    ';
  
}
  echo $output;
curl_close($curl);
?>
