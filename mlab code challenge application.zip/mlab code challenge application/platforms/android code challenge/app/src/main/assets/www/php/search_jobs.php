<?php
if(isset($_POST['search_id'])){
    //search keyword from front-end
    $search_id = $_POST['search_id'];

//Tyson Moyahabo 
//Full stack developer

$url ="https://us-central1-mlab-challenge.cloudfunctions.net/jobs";
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_ENCODING, "");
$curlData = curl_exec($curl);

$data = json_decode($curlData, true);

//data selection
//echo 'job id : '.$data['id'].'<br/><br/>';
//echo 'job type : '.$data['type'].'<br/><br/>';
//echo 'job type : '.$data['title'].'<br/><br/>';
//echo 'job website : '.$data['url'].'<br/><br/>';
//echo 'date posted : '.$data['created_at'].'<br/><br/>';
//echo 'company name : '.$data['company'].'<br/><br/>';
//echo 'comapny url : '.$data['company_url'].'<br/><br/>';
//echo 'job location : '.$data['location'].'<br/><br/>';
//echo 'job description : '.$data['description'].'<br/><br/>';
//echo 'how to apply : '.$data['how_to_apply'].'<br/><br/>';
//echo 'logo : '.$data['company_logo'].'<br/><br/>';

//break no results loop
$i = 1;

//checking if search id is empty
if(empty(trim($search_id))) {
    echo "";
}else {
        foreach($data as $key=> $value){
    
     //image url link company logo
    if($value["company_logo"] == ""){
        $img_link = "../img/default.png";
    }else {
        $img_link = $value["company_logo"];
    }
   //searching description for specific word 
    if(stristr($value["description"], $search_id)){
    $output .= '
        <!-- search results-->
        <a href="about.html?id='.$value['id'].'">  
        <div class="job-search">
        <div class="job-search-logo">
        <img src="'.$img_link.'">
        </div>
        <div class="job-search-info">
        <h1>'.$value['title'].'</h1>
        <h2>'.$value['company'].'</h2>
        <h5>'.$value['location'].'</h5>
        <p>'.$value['created_at'].'</p>
        <hr/>
        </div>
        </div>
        </a>
      ';  
    }
  
}
echo $output;
}
}
?>
