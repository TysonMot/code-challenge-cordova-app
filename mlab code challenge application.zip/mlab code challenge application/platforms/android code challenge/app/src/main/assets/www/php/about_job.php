<?php
if(isset($_POST['done'])){
   //job id ajax request
   $id = $_POST['id'];
   
$url = "https://us-central1-mlab-challenge.cloudfunctions.net/job?id=$id";
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_ENCODING, "");
$curlData = curl_exec($curl);

$data = json_decode($curlData, true);

//data selection
//echo 'job id : '.$data['id'].'<br/><br/>';
//echo 'job type : '.$data['type'].'<br/><br/>';
//echo 'job type : '.$data['title'].'<br/><br/>';
//echo 'job website : '.$data['url'].'<br/><br/>';
//echo 'date posted : '.$data['created_at'].'<br/><br/>';
//echo 'company name : '.$data['company'].'<br/><br/>';
//echo 'comapny url : '.$data['company_url'].'<br/><br/>';
//echo 'job location : '.$data['location'].'<br/><br/>';
//echo 'job description : '.$data['description'].'<br/><br/>';
//echo 'how to apply : '.$data['how_to_apply'].'<br/><br/>';
//echo 'logo : '.$data['company_logo'].'<br/><br/>';
    


    //conditions
   //image url link company logo
    if($data["company_logo"] == ""){
        $img_link = "../img/default.png";
    }else {
        $img_link = $data["company_logo"];
    }
    
    
    ///display job listings
    $output .= ' 
    <div class="about-job">
    <div class="about-job-banner">
    <img src="'.$img_link.'">
    </div>
    <div class="about-job-details">
    <h1>'.$data['title'].'</h1>
    <h2>'.$data['company'].'</h2>
    <p class="dates">'.$data['created_at'].'</p>
    <p>'.$data['description'].' </p>
    <h3>Job type</h3>
    <p>'.$data['type'].'</p>
    <h3>How to Apply</h3>
    <p>'.$data['how_to_apply'].'</p>
    
    <!-- footer for apply button-->
    <div class="about-job-apply-hidden">
    <a href="'.$data['url'].'" target="_blank"><p><span class="glyphicon glyphicon-envelope"></span>Apply Now</p></a>
    </div>
    <!-- footer for apply button -->
    
    </div>
    </div>
    <!-- footer for apply button-->
    <div class="about-job-apply">
    <a href="'.$data['url'].'" target="_blank"><p><span class="glyphicon glyphicon-envelope"></span>Apply Now</p></a>
    </div>
    
    ';
    echo $output;

curl_close($curl); 
}

?>
