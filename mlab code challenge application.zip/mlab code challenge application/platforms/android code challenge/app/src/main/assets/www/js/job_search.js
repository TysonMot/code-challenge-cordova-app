//a call to disable default back button
//demonstration of using device ready plugin.
//all plugins should be called under this device ready function
//firebase in app live notifications and other plugins
document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
    document.addEventListener("backbutton", function (e) {
        e.preventDefault();
    }, false);
}
//function for searching job using keywords from job description
  function fill(Value) {
      $('#search').val(Value);
      $('#display').hide();
        $('#error_netowrk').hide();
  }
  $(document).ready(function() {
      $("#search").keyup(function() {
          var search_id = $('#search').val();
          $('.search-landing').hide();
          $('.loader-search').show();
          if (search_id == "") {
            //  $('.container').show();
              $("#display").html("");
              $('.job-search-no-results').hide();
              $('.loader-search').hide();
              $('.search-landing').show();
              $('#error_netowrk').hide();
          } else {
              $.ajax({
                  type: "POST",
                  url: "../php/search_jobs.php",
                  data: {search_id: search_id},
                  success: function(data) {
                    if(data == ""){
                      $('.loader-search').hide();
                      $('.search-landing').hide();
                        $('#error_netowrk').hide();
                      $("#display").html(data).hide();
                      $('.job-search-no-results').show();
                    }else {
                      $('.job-search-no-results').hide();
                      //  $('.container').hide();
                      $('.loader-search').hide();
                      $('.search-landing').hide();
                        $('#error_netowrk').hide();
                      $("#display").html(data).show();
                    }
                  },
                  error: function (e) {
                    //throw error message here
                    $('.loader-search').hide();
                      $('.search-landing').hide();
                      $('#error_netowrk').show();
                  }
              });
          }
      });
  });
