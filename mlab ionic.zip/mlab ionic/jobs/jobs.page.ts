import { JobsService } from './../../services/jobs.service';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.page.html',
  styleUrls: ['./jobs.page.scss'],
})
export class JobsPage implements OnInit {
information = null;
results: Observable<any>;

  constructor(public loadingController: LoadingController,private jobsService: JobsService) {
   }

  ngOnInit() {
    this.jobsService.jobInfo().subscribe(result => {
    this.information = result;
    this.results = this.jobsService.jobInfo();
    console.log('Raw data job page services : ', this.results = this.jobsService.jobInfo());
  });
  }


}
