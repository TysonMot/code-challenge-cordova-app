import { JobsService } from './../../services/jobs.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-jobs-details',
  templateUrl: './jobs-details.page.html',
  styleUrls: ['./jobs-details.page.scss'],
})
export class JobsDetailsPage implements OnInit {
job_information = null;
  constructor(private activatedRoute: ActivatedRoute, private jobsService: JobsService) { }

  ngOnInit() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    this.jobsService.getJob_details(id).subscribe(result => {
      this.job_information = result;
    });
    //get data with ajax
  }
  //redirect to job posters website
  Apply_now() {
    window.open(this.job_information.url, '_blank');
  }

}
