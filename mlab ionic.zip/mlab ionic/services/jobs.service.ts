import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Component } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class JobsService {
  //url api
  url_api = 'https://us-central1-mlab-challenge.cloudfunctions.net/jobs/';
//constructor for http client headers
  constructor(private http: HttpClient){}
//function for getting data from api
  jobInfo(): Observable<any>{
    return this.http.get(this.url_api)
    .pipe(
        map(results => {
          console.log('Raw data job services : ', results);
          if(results != null){
            console.log(results);
          }else {
            console.log("Not working");
          }
          return results;
        })
      );
  }
  //get job by its id
  getJob_details(id) {
   return this.http.get('https://us-central1-mlab-challenge.cloudfunctions.net/job?id='+id);
 }
   //subscribe

}
